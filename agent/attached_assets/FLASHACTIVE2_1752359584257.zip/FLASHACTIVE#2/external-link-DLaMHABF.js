import{b as l}from"./core-9wIKku2e.js";import"./index-ILgzZvQr.js";import"./index.es-I2zYtwzF.js";import"./events-DQ172AOg.js";const t=l`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.74 3.99a1 1 0 0 1 1-1H11a1 1 0 0 1 1 1v6.26a1 1 0 0 1-2 0V6.4l-6.3 6.3a1 1 0 0 1-1.4-1.42l6.29-6.3H4.74a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`;export{t as externalLinkSvg};
