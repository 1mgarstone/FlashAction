
const { Web3 } = require('web3');
const fs = require('fs');
const path = require('path');

// Configuration
const NETWORK_URL = process.env.NETWORK_URL || 'http://127.0.0.1:8545'; // Local ganache
const PRIVATE_KEY = process.env.PRIVATE_KEY;

async function deployContract(contractName) {
    const web3 = new Web3(NETWORK_URL);
    
    // Read compiled contract
    const buildPath = path.join(__dirname, 'build');
    const bytecode = fs.readFileSync(path.join(buildPath, `${contractName}.bin`), 'utf8');
    const abi = JSON.parse(fs.readFileSync(path.join(buildPath, `${contractName}.abi`), 'utf8'));
    
    // Create contract instance
    const contract = new web3.eth.Contract(abi);
    
    // Add account if private key is provided
    if (PRIVATE_KEY) {
        const account = web3.eth.accounts.privateKeyToAccount(PRIVATE_KEY);
        web3.eth.accounts.wallet.add(account);
        web3.eth.defaultAccount = account.address;
    }
    
    console.log(`Deploying ${contractName}...`);
    console.log('Make sure you have set NETWORK_URL and PRIVATE_KEY environment variables');
    console.log('Current network:', NETWORK_URL);
    
    return contract;
}

async function deployContractWithParams(contractName, constructorParams = []) {
    const web3 = new Web3(NETWORK_URL);
    
    // Read compiled contract
    const buildPath = path.join(__dirname, 'build');
    const bytecode = fs.readFileSync(path.join(buildPath, `${contractName}.bin`), 'utf8');
    const abi = JSON.parse(fs.readFileSync(path.join(buildPath, `${contractName}.abi`), 'utf8'));
    
    // Create contract instance
    const contract = new web3.eth.Contract(abi);
    
    // Add account if private key is provided
    if (PRIVATE_KEY) {
        const account = web3.eth.accounts.privateKeyToAccount(PRIVATE_KEY);
        web3.eth.accounts.wallet.add(account);
        web3.eth.defaultAccount = account.address;
        
        console.log(`Deploying ${contractName} with account: ${account.address}`);
        
        // Deploy contract
        const deployedContract = await contract.deploy({
            data: '0x' + bytecode,
            arguments: constructorParams
        }).send({
            from: account.address,
            gas: '5000000',
            gasPrice: '20000000000'
        });
        
        console.log(`${contractName} deployed at: ${deployedContract.options.address}`);
        return deployedContract;
    } else {
        console.log(`${contractName} ready for deployment (set PRIVATE_KEY to deploy)`);
        return contract;
    }
}

async function main() {
    try {
        console.log('=== Ultimate Arbitrage Smart Contract Deployment ===');
        console.log('Network:', NETWORK_URL);
        console.log('Configure NETWORK_URL and PRIVATE_KEY in Secrets for actual deployment\n');
        
        // Network-specific addresses (Ethereum mainnet)
        const AAVE_POOL_ADDRESS_PROVIDER = '0x2f39d218133AFaB8F2B819B1066c7E434Ad94E9e';
        const UNISWAP_ROUTER = '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D';
        const SUSHISWAP_ROUTER = '0xd9e1cE17f2641f24aE83637ab66a2cca9C378B9F';
        
        console.log('Available contracts for deployment:');
        console.log('1. Arbitrage - Simple arbitrage between Uniswap and Sushiswap');
        console.log('2. FlashLoan - Basic flash loan from Aave');
        console.log('3. Flash-Loan-Arbitrage - Flash loan with arbitrage');
        console.log('4. UltimateArbitrage - Combined ultimate arbitrage contract\n');
        
        // Deploy Ultimate Arbitrage Contract
        if (PRIVATE_KEY) {
            console.log('Deploying UltimateArbitrage contract...');
            const ultimateArbitrage = await deployContractWithParams('UltimateArbitrage', [
                AAVE_POOL_ADDRESS_PROVIDER,
                UNISWAP_ROUTER,
                SUSHISWAP_ROUTER
            ]);
            
            console.log('\n=== Deployment Summary ===');
            console.log(`UltimateArbitrage: ${ultimateArbitrage.options.address}`);
            console.log('\n=== Usage Instructions ===');
            console.log('1. Fund the contract with tokens for arbitrage');
            console.log('2. Call getPriceComparison() to check opportunities');
            console.log('3. Execute arbitrage strategies:');
            console.log('   - executeSimpleArbitrage()');
            console.log('   - executeFlashLoanArbitrage()');
            console.log('   - executeTriangularArbitrage()');
            console.log('4. Withdraw profits using withdrawToken()');
            
        } else {
            console.log('Set PRIVATE_KEY environment variable to deploy contracts');
            console.log('Example addresses that would be used:');
            console.log(`Aave Pool Provider: ${AAVE_POOL_ADDRESS_PROVIDER}`);
            console.log(`Uniswap Router: ${UNISWAP_ROUTER}`);
            console.log(`Sushiswap Router: ${SUSHISWAP_ROUTER}`);
        }
        
    } catch (error) {
        console.error('Deployment error:', error);
        console.error('Make sure you have:');
        console.error('1. Compiled contracts (run "npm run compile")');
        console.error('2. Set NETWORK_URL and PRIVATE_KEY in environment');
        console.error('3. Sufficient ETH for gas fees');
    }
}

main();
