
const { Web3 } = require('web3');
const fs = require('fs');
const path = require('path');

class ArbitrageUtils {
    constructor(networkUrl, privateKey) {
        this.web3 = new Web3(networkUrl);
        this.privateKey = privateKey;
        
        if (privateKey) {
            const account = this.web3.eth.accounts.privateKeyToAccount(privateKey);
            this.web3.eth.accounts.wallet.add(account);
            this.web3.eth.defaultAccount = account.address;
        }
    }
    
    async loadContract(contractName, contractAddress) {
        const buildPath = path.join(__dirname, 'build');
        const abi = JSON.parse(fs.readFileSync(path.join(buildPath, `${contractName}.abi`), 'utf8'));
        return new this.web3.eth.Contract(abi, contractAddress);
    }
    
    async getGasPrice() {
        return await this.web3.eth.getGasPrice();
    }
    
    async getBalance(address, tokenAddress = null) {
        if (tokenAddress) {
            // ERC20 token balance
            const tokenAbi = [
                {
                    "constant": true,
                    "inputs": [{"name": "_owner", "type": "address"}],
                    "name": "balanceOf",
                    "outputs": [{"name": "balance", "type": "uint256"}],
                    "type": "function"
                }
            ];
            const tokenContract = new this.web3.eth.Contract(tokenAbi, tokenAddress);
            return await tokenContract.methods.balanceOf(address).call();
        } else {
            // ETH balance
            return await this.web3.eth.getBalance(address);
        }
    }
    
    async estimateGas(contract, method, params = []) {
        try {
            return await contract.methods[method](...params).estimateGas();
        } catch (error) {
            console.error(`Gas estimation failed for ${method}:`, error);
            return 500000; // Default gas limit
        }
    }
    
    async executeArbitrage(contractAddress, type, params) {
        const contract = await this.loadContract('UltimateArbitrage', contractAddress);
        
        switch (type) {
            case 'simple':
                return await this.executeSimpleArbitrage(contract, params);
            case 'flashloan':
                return await this.executeFlashLoanArbitrage(contract, params);
            case 'triangular':
                return await this.executeTriangularArbitrage(contract, params);
            default:
                throw new Error('Unknown arbitrage type');
        }
    }
    
    async executeSimpleArbitrage(contract, { tokenA, tokenB, amountIn, buyOnUniswap }) {
        const gasLimit = await this.estimateGas(contract, 'executeSimpleArbitrage', [tokenA, tokenB, amountIn, buyOnUniswap]);
        const gasPrice = await this.getGasPrice();
        
        return await contract.methods.executeSimpleArbitrage(tokenA, tokenB, amountIn, buyOnUniswap).send({
            from: this.web3.eth.defaultAccount,
            gas: gasLimit,
            gasPrice: gasPrice
        });
    }
    
    async executeFlashLoanArbitrage(contract, { asset, amount }) {
        const gasLimit = await this.estimateGas(contract, 'executeFlashLoanArbitrage', [asset, amount]);
        const gasPrice = await this.getGasPrice();
        
        return await contract.methods.executeFlashLoanArbitrage(asset, amount).send({
            from: this.web3.eth.defaultAccount,
            gas: gasLimit,
            gasPrice: gasPrice
        });
    }
    
    async executeTriangularArbitrage(contract, { tokenA, tokenB, tokenC, amountIn }) {
        const gasLimit = await this.estimateGas(contract, 'executeTriangularArbitrage', [tokenA, tokenB, tokenC, amountIn]);
        const gasPrice = await this.getGasPrice();
        
        return await contract.methods.executeTriangularArbitrage(tokenA, tokenB, tokenC, amountIn).send({
            from: this.web3.eth.defaultAccount,
            gas: gasLimit,
            gasPrice: gasPrice
        });
    }
    
    async getPriceComparison(contractAddress, tokenA, tokenB, amountIn) {
        const contract = await this.loadContract('UltimateArbitrage', contractAddress);
        return await contract.methods.getPriceComparison(tokenA, tokenB, amountIn).call();
    }
    
    async monitorPrices(contractAddress, pairs, interval = 5000) {
        console.log('Starting price monitoring...');
        
        setInterval(async () => {
            for (const pair of pairs) {
                try {
                    const { tokenA, tokenB, amount } = pair;
                    const priceData = await this.getPriceComparison(contractAddress, tokenA, tokenB, amount);
                    
                    console.log(`${pair.name}: Uniswap=${priceData.uniswapPrice}, Sushiswap=${priceData.sushiswapPrice}, Profitable=${priceData.profitableOnUniswap ? 'Uniswap' : 'Sushiswap'}`);
                } catch (error) {
                    console.error(`Error monitoring ${pair.name}:`, error);
                }
            }
        }, interval);
    }
    
    formatAmount(amount, decimals = 18) {
        return this.web3.utils.fromWei(amount.toString(), 'ether');
    }
    
    parseAmount(amount, decimals = 18) {
        return this.web3.utils.toWei(amount.toString(), 'ether');
    }
}

module.exports = ArbitrageUtils;
