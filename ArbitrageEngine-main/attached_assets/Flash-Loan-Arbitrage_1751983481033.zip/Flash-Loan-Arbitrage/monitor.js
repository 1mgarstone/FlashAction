
const ArbitrageUtils = require('./utils');
require('dotenv').config();

const NETWORK_URL = process.env.NETWORK_URL || 'http://127.0.0.1:8545';
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const CONTRACT_ADDRESS = process.env.CONTRACT_ADDRESS;

// Common token addresses (Ethereum mainnet)
const TOKENS = {
    WETH: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    USDT: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
    USDC: '0xA0b86a33E6441b8e532C89F4F6a2C4a7fC3Ad18c',
    WBTC: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
    DAI: '0x6B175474E89094C44Da98b954EedeAC495271d0F'
};

const TRADING_PAIRS = [
    {
        name: 'WETH/USDT',
        tokenA: TOKENS.WETH,
        tokenB: TOKENS.USDT,
        amount: '1000000000000000000' // 1 WETH
    },
    {
        name: 'WBTC/USDT',
        tokenA: TOKENS.WBTC,
        tokenB: TOKENS.USDT,
        amount: '100000000' // 1 WBTC (8 decimals)
    },
    {
        name: 'USDT/USDC',
        tokenA: TOKENS.USDT,
        tokenB: TOKENS.USDC,
        amount: '1000000000' // 1000 USDT (6 decimals)
    }
];

async function main() {
    console.log('🔍 Starting Ultimate Arbitrage Monitor');
    console.log('Network:', NETWORK_URL);
    console.log('Contract:', CONTRACT_ADDRESS || 'Not set');
    console.log('=====================================\n');
    
    if (!CONTRACT_ADDRESS) {
        console.log('❌ CONTRACT_ADDRESS not set in environment variables');
        console.log('Set CONTRACT_ADDRESS after deploying the UltimateArbitrage contract');
        return;
    }
    
    const utils = new ArbitrageUtils(NETWORK_URL, PRIVATE_KEY);
    
    // Monitor prices continuously
    console.log('📊 Starting price monitoring for pairs:');
    TRADING_PAIRS.forEach(pair => {
        console.log(`   - ${pair.name}`);
    });
    console.log('\n');
    
    // Check opportunities every 10 seconds
    setInterval(async () => {
        console.log(`⏰ ${new Date().toLocaleTimeString()} - Checking opportunities...`);
        
        for (const pair of TRADING_PAIRS) {
            try {
                const priceData = await utils.getPriceComparison(
                    CONTRACT_ADDRESS,
                    pair.tokenA,
                    pair.tokenB,
                    pair.amount
                );
                
                const uniswapPrice = utils.formatAmount(priceData.uniswapPrice);
                const sushiswapPrice = utils.formatAmount(priceData.sushiswapPrice);
                const difference = Math.abs(uniswapPrice - sushiswapPrice);
                const percentageDiff = (difference / Math.max(uniswapPrice, sushiswapPrice)) * 100;
                
                console.log(`${pair.name}:`);
                console.log(`   Uniswap: ${uniswapPrice}`);
                console.log(`   Sushiswap: ${sushiswapPrice}`);
                console.log(`   Difference: ${difference.toFixed(6)} (${percentageDiff.toFixed(2)}%)`);
                
                if (percentageDiff > 0.5) { // 0.5% threshold
                    console.log(`   🎯 OPPORTUNITY DETECTED! ${percentageDiff.toFixed(2)}% difference`);
                    console.log(`   📈 Buy on: ${priceData.profitableOnUniswap ? 'Sushiswap' : 'Uniswap'}`);
                    console.log(`   📉 Sell on: ${priceData.profitableOnUniswap ? 'Uniswap' : 'Sushiswap'}`);
                    
                    // Auto-execute if private key is available
                    if (PRIVATE_KEY) {
                        console.log(`   🚀 Auto-executing arbitrage...`);
                        try {
                            await utils.executeArbitrage(CONTRACT_ADDRESS, 'simple', {
                                tokenA: pair.tokenA,
                                tokenB: pair.tokenB,
                                amountIn: pair.amount,
                                buyOnUniswap: !priceData.profitableOnUniswap
                            });
                            console.log(`   ✅ Arbitrage executed successfully!`);
                        } catch (error) {
                            console.log(`   ❌ Arbitrage execution failed: ${error.message}`);
                        }
                    }
                }
                
                console.log('');
            } catch (error) {
                console.error(`❌ Error checking ${pair.name}:`, error.message);
            }
        }
        
        console.log('=====================================\n');
    }, 10000); // Check every 10 seconds
    
    // Keep the process running
    process.on('SIGINT', () => {
        console.log('\n👋 Stopping monitor...');
        process.exit(0);
    });
}

if (require.main === module) {
    main().catch(console.error);
}

module.exports = { TOKENS, TRADING_PAIRS };
