
const { Web3 } = require('web3');
const ArbitrageUtils = require('./utils');
const { TOKENS, TRADING_PAIRS } = require('./monitor');
require('dotenv').config();

class TradingEngine {
    constructor() {
        this.web3 = new Web3(process.env.NETWORK_URL || 'http://127.0.0.1:8545');
        this.utils = new ArbitrageUtils(process.env.NETWORK_URL, process.env.PRIVATE_KEY);
        this.contractAddress = process.env.CONTRACT_ADDRESS;
        this.isRunning = false;
        this.profits = 0;
        this.totalTrades = 0;
        this.successfulTrades = 0;
        this.minProfitThreshold = 0.5; // 0.5%
        this.maxSlippage = 2; // 2%
        this.gasPrice = null;
        this.lastPriceUpdate = null;
        this.activeOpportunities = [];
    }

    async initialize() {
        console.log('🔧 Initializing Trading Engine...');
        
        try {
            // Load contract
            if (this.contractAddress) {
                this.contract = await this.utils.loadContract('UltimateArbitrage', this.contractAddress);
                console.log('✅ Contract loaded successfully');
            } else {
                console.log('⚠️  No contract address set. Set CONTRACT_ADDRESS environment variable');
            }

            // Get current gas price
            this.gasPrice = await this.web3.eth.getGasPrice();
            console.log(`⛽ Current gas price: ${this.web3.utils.fromWei(this.gasPrice, 'gwei')} gwei`);

            // Initialize price monitoring
            this.startPriceMonitoring();
            
            console.log('🚀 Trading Engine initialized successfully');
            return true;
        } catch (error) {
            console.error('❌ Trading Engine initialization failed:', error);
            return false;
        }
    }

    async startPriceMonitoring() {
        console.log('📊 Starting advanced price monitoring...');
        
        setInterval(async () => {
            if (!this.isRunning) return;
            
            try {
                await this.scanOpportunities();
                await this.updateGasPrice();
            } catch (error) {
                console.error('Price monitoring error:', error);
            }
        }, 3000); // Check every 3 seconds
    }

    async scanOpportunities() {
        const opportunities = [];
        
        for (const pair of TRADING_PAIRS) {
            try {
                const opportunity = await this.analyzePair(pair);
                if (opportunity) {
                    opportunities.push(opportunity);
                }
            } catch (error) {
                console.error(`Error analyzing ${pair.name}:`, error);
            }
        }

        this.activeOpportunities = opportunities;
        this.lastPriceUpdate = Date.now();

        // Auto-execute profitable opportunities
        if (this.isRunning && opportunities.length > 0) {
            const bestOpportunity = opportunities
                .filter(opp => opp.profitPercent > this.minProfitThreshold)
                .sort((a, b) => b.profitPercent - a.profitPercent)[0];

            if (bestOpportunity) {
                await this.executeOpportunity(bestOpportunity);
            }
        }
    }

    async analyzePair(pair) {
        if (!this.contractAddress) return null;

        try {
            const priceData = await this.utils.getPriceComparison(
                this.contractAddress,
                pair.tokenA,
                pair.tokenB,
                pair.amount
            );

            const uniswapPrice = parseFloat(priceData.uniswapPrice);
            const sushiswapPrice = parseFloat(priceData.sushiswapPrice);
            const difference = Math.abs(uniswapPrice - sushiswapPrice);
            const profitPercent = (difference / Math.max(uniswapPrice, sushiswapPrice)) * 100;

            // Calculate gas costs
            const estimatedGasCost = await this.estimateTransactionCost();
            const profitUSD = await this.calculateProfitUSD(difference, pair.tokenB);
            const netProfitUSD = profitUSD - estimatedGasCost;

            if (profitPercent > 0.3 && netProfitUSD > 5) { // Minimum $5 net profit
                return {
                    pair: pair.name,
                    tokenA: pair.tokenA,
                    tokenB: pair.tokenB,
                    amount: pair.amount,
                    uniswapPrice,
                    sushiswapPrice,
                    profitPercent,
                    profitUSD,
                    netProfitUSD,
                    estimatedGasCost,
                    buyOnUniswap: !priceData.profitableOnUniswap,
                    confidence: this.calculateConfidence(profitPercent, netProfitUSD),
                    timestamp: Date.now()
                };
            }

            return null;
        } catch (error) {
            console.error(`Error analyzing pair ${pair.name}:`, error);
            return null;
        }
    }

    async executeOpportunity(opportunity) {
        console.log(`🎯 Executing opportunity: ${opportunity.pair} (+${opportunity.profitPercent.toFixed(2)}%)`);
        console.log(`💰 Expected profit: $${opportunity.netProfitUSD.toFixed(2)}`);

        try {
            this.totalTrades++;

            // Choose strategy based on opportunity
            let txHash;
            if (opportunity.netProfitUSD > 100) {
                // Use flash loan for larger opportunities
                txHash = await this.executeFlashLoanArbitrage(opportunity);
            } else {
                // Use simple arbitrage for smaller opportunities
                txHash = await this.executeSimpleArbitrage(opportunity);
            }

            if (txHash) {
                this.successfulTrades++;
                this.profits += opportunity.netProfitUSD;
                
                console.log(`✅ Trade executed successfully! TX: ${txHash}`);
                console.log(`💰 Total profits: $${this.profits.toFixed(2)}`);
                console.log(`📊 Success rate: ${((this.successfulTrades / this.totalTrades) * 100).toFixed(1)}%`);
                
                return true;
            }
        } catch (error) {
            console.error(`❌ Trade execution failed: ${error.message}`);
            return false;
        }
    }

    async executeSimpleArbitrage(opportunity) {
        const tx = await this.utils.executeSimpleArbitrage(this.contract, {
            tokenA: opportunity.tokenA,
            tokenB: opportunity.tokenB,
            amountIn: opportunity.amount,
            buyOnUniswap: opportunity.buyOnUniswap
        });
        return tx.transactionHash;
    }

    async executeFlashLoanArbitrage(opportunity) {
        const tx = await this.utils.executeFlashLoanArbitrage(this.contract, {
            asset: opportunity.tokenA,
            amount: opportunity.amount
        });
        return tx.transactionHash;
    }

    async estimateTransactionCost() {
        const gasLimit = 500000; // Conservative estimate
        const gasCostWei = BigInt(gasLimit) * BigInt(this.gasPrice);
        const gasCostEth = this.web3.utils.fromWei(gasCostWei.toString(), 'ether');
        
        // Convert to USD (mock ETH price of $2000)
        const ethPriceUSD = 2000;
        return parseFloat(gasCostEth) * ethPriceUSD;
    }

    async calculateProfitUSD(profitTokens, tokenAddress) {
        // Mock token prices for calculation
        const prices = {
            [TOKENS.WETH]: 2000,
            [TOKENS.USDT]: 1,
            [TOKENS.USDC]: 1,
            [TOKENS.WBTC]: 35000
        };

        const tokenPriceUSD = prices[tokenAddress] || 1;
        const profitEth = this.web3.utils.fromWei(profitTokens.toString(), 'ether');
        return parseFloat(profitEth) * tokenPriceUSD;
    }

    calculateConfidence(profitPercent, netProfitUSD) {
        let score = 0;
        
        // Profit percentage weight
        if (profitPercent > 2) score += 40;
        else if (profitPercent > 1) score += 30;
        else if (profitPercent > 0.5) score += 20;
        
        // Net profit weight
        if (netProfitUSD > 100) score += 40;
        else if (netProfitUSD > 50) score += 30;
        else if (netProfitUSD > 20) score += 20;
        else if (netProfitUSD > 5) score += 10;
        
        // Market conditions weight
        score += 20; // Base score for market liquidity
        
        if (score >= 80) return 'high';
        if (score >= 60) return 'medium';
        return 'low';
    }

    async updateGasPrice() {
        try {
            const newGasPrice = await this.web3.eth.getGasPrice();
            this.gasPrice = newGasPrice;
        } catch (error) {
            console.error('Failed to update gas price:', error);
        }
    }

    startTrading() {
        if (this.isRunning) {
            console.log('⚠️  Trading engine is already running');
            return;
        }

        console.log('🚀 Starting automated trading...');
        this.isRunning = true;
        
        // Print trading parameters
        console.log(`📊 Trading Parameters:`);
        console.log(`   Min Profit Threshold: ${this.minProfitThreshold}%`);
        console.log(`   Max Slippage: ${this.maxSlippage}%`);
        console.log(`   Contract: ${this.contractAddress || 'Not set'}`);
    }

    stopTrading() {
        console.log('🛑 Stopping automated trading...');
        this.isRunning = false;
        
        // Print session summary
        console.log(`\n📊 Trading Session Summary:`);
        console.log(`   Total Trades: ${this.totalTrades}`);
        console.log(`   Successful Trades: ${this.successfulTrades}`);
        console.log(`   Success Rate: ${this.totalTrades > 0 ? ((this.successfulTrades / this.totalTrades) * 100).toFixed(1) : 0}%`);
        console.log(`   Total Profits: $${this.profits.toFixed(2)}`);
    }

    getActiveOpportunities() {
        return this.activeOpportunities.map(opp => ({
            pair: opp.pair,
            profit: `${opp.profitPercent.toFixed(2)}%`,
            profitUSD: `$${opp.netProfitUSD.toFixed(2)}`,
            confidence: opp.confidence,
            age: Math.floor((Date.now() - opp.timestamp) / 1000) + 's'
        }));
    }

    getStats() {
        return {
            isRunning: this.isRunning,
            totalTrades: this.totalTrades,
            successfulTrades: this.successfulTrades,
            successRate: this.totalTrades > 0 ? ((this.successfulTrades / this.totalTrades) * 100).toFixed(1) : 0,
            totalProfits: this.profits.toFixed(2),
            activeOpportunities: this.activeOpportunities.length,
            lastUpdate: this.lastPriceUpdate ? new Date(this.lastPriceUpdate).toISOString() : null
        };
    }
}

module.exports = TradingEngine;
