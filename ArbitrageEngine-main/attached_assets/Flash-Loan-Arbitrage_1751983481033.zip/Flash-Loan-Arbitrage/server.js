
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const fs = require('fs');
const TradingEngine = require('./trading-engine');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const PORT = process.env.PORT || 5000;

// Initialize trading engine
const tradingEngine = new TradingEngine();

app.use(express.static('.'));
app.use(express.json());

// Serve contract ABIs
app.get('/api/contracts', (req, res) => {
    const buildDir = path.join(__dirname, 'build');
    
    if (!fs.existsSync(buildDir)) {
        return res.json({ error: 'Contracts not compiled. Run compile command first.' });
    }
    
    const contracts = {};
    const files = fs.readdirSync(buildDir);
    
    files.forEach(file => {
        if (file.endsWith('.abi')) {
            const contractName = file.replace('.abi', '');
            try {
                const abi = JSON.parse(fs.readFileSync(path.join(buildDir, file), 'utf8'));
                const binPath = path.join(buildDir, `${contractName}.bin`);
                const bytecode = fs.existsSync(binPath) ? fs.readFileSync(binPath, 'utf8') : null;
                
                contracts[contractName] = { abi, bytecode };
            } catch (error) {
                console.error(`Error reading ${file}:`, error);
            }
        }
    });
    
    res.json(contracts);
});

// Price monitoring endpoint
app.get('/api/prices/:tokenA/:tokenB/:amount', async (req, res) => {
    try {
        const { tokenA, tokenB, amount } = req.params;
        
        // This would connect to actual DEX APIs in production
        const mockPriceData = {
            uniswap: parseFloat(amount) * 1.02,
            sushiswap: parseFloat(amount) * 1.01,
            difference: 0.01,
            profitable: true,
            timestamp: Date.now()
        };
        
        res.json(mockPriceData);
    } catch (error) {
        res.status(500).json({ error: 'Price fetch failed' });
    }
});

// Real arbitrage opportunities endpoint
app.get('/api/opportunities', (req, res) => {
    const opportunities = tradingEngine.getActiveOpportunities();
    res.json(opportunities);
});

// Trading engine control endpoints
app.post('/api/trading/start', (req, res) => {
    tradingEngine.startTrading();
    res.json({ success: true, message: 'Trading started' });
});

app.post('/api/trading/stop', (req, res) => {
    tradingEngine.stopTrading();
    res.json({ success: true, message: 'Trading stopped' });
});

app.get('/api/trading/stats', (req, res) => {
    const stats = tradingEngine.getStats();
    res.json(stats);
});

// Execute manual arbitrage
app.post('/api/arbitrage/execute', async (req, res) => {
    try {
        const { tokenA, tokenB, amount, type } = req.body;
        
        if (!process.env.PRIVATE_KEY) {
            return res.status(400).json({ error: 'Private key not configured' });
        }

        const opportunity = {
            tokenA,
            tokenB,
            amount,
            buyOnUniswap: true // This would be calculated in real implementation
        };

        let result;
        if (type === 'flashloan') {
            result = await tradingEngine.executeFlashLoanArbitrage(opportunity);
        } else {
            result = await tradingEngine.executeSimpleArbitrage(opportunity);
        }

        res.json({ success: true, transactionHash: result });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Flash loan calculation endpoint
app.post('/api/flashloan/calculate', async (req, res) => {
    try {
        const { asset, amount } = req.body;
        
        // Aave flash loan fee is 0.09%
        const fee = parseFloat(amount) * 0.0009;
        const totalRepayment = parseFloat(amount) + fee;
        
        // Mock profit calculation based on current market conditions
        const mockProfit = parseFloat(amount) * 0.012; // 1.2% potential profit
        const netProfit = mockProfit - fee;
        
        res.json({
            loanAmount: amount,
            fee: fee.toFixed(6),
            totalRepayment: totalRepayment.toFixed(6),
            estimatedProfit: mockProfit.toFixed(6),
            netProfit: netProfit.toFixed(6),
            feePercent: '0.09%',
            profitable: netProfit > 0
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get user balances (mock for demo)
app.get('/api/balances/:address', async (req, res) => {
    try {
        const { address } = req.params;
        
        // In real implementation, this would query actual blockchain balances
        const balances = {
            ETH: '2.456',
            USDT: '1250.00',
            USDC: '850.75',
            WBTC: '0.025',
            totalUSD: '8420.50'
        };
        
        res.json(balances);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// WebSocket connections for real-time updates
wss.on('connection', (ws) => {
    console.log('New WebSocket connection established');
    
    // Send initial data
    ws.send(JSON.stringify({
        type: 'welcome',
        message: 'Connected to Ultimate Arbitrage Platform'
    }));
    
    // Send trading stats every 5 seconds
    const statsInterval = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
            const stats = tradingEngine.getStats();
            const opportunities = tradingEngine.getActiveOpportunities();
            
            ws.send(JSON.stringify({
                type: 'stats_update',
                data: {
                    ...stats,
                    opportunities: opportunities.slice(0, 5) // Send top 5 opportunities
                }
            }));
        }
    }, 5000);
    
    ws.on('message', (message) => {
        try {
            const data = JSON.parse(message);
            
            switch (data.type) {
                case 'start_trading':
                    tradingEngine.startTrading();
                    ws.send(JSON.stringify({ type: 'trading_started' }));
                    break;
                    
                case 'stop_trading':
                    tradingEngine.stopTrading();
                    ws.send(JSON.stringify({ type: 'trading_stopped' }));
                    break;
                    
                case 'get_opportunities':
                    const opportunities = tradingEngine.getActiveOpportunities();
                    ws.send(JSON.stringify({
                        type: 'opportunities',
                        data: opportunities
                    }));
                    break;
            }
        } catch (error) {
            console.error('WebSocket message error:', error);
        }
    });
    
    ws.on('close', () => {
        clearInterval(statsInterval);
        console.log('WebSocket connection closed');
    });
});

app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Ultimate Arbitrage Platform</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
                .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
                h1 { color: #2c3e50; text-align: center; }
                .section { margin: 30px 0; }
                .contract-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
                .contract-card { background: #f8f9fa; padding: 20px; border-radius: 8px; border-left: 4px solid #3498db; }
                .api-section { background: #e8f4f8; padding: 20px; border-radius: 8px; }
                .command { background: #2c3e50; color: white; padding: 10px; border-radius: 4px; font-family: monospace; }
                .btn { display: inline-block; background: #3498db; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; margin: 5px; }
                .btn:hover { background: #2980b9; }
                .feature { background: #ecf0f1; padding: 15px; margin: 10px 0; border-radius: 5px; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🚀 Ultimate Arbitrage Platform</h1>
                
                <div class="section">
                    <h2>Smart Contracts</h2>
                    <div class="contract-grid">
                        <div class="contract-card">
                            <h3>UltimateArbitrage.sol</h3>
                            <p>The ultimate contract combining all arbitrage strategies with flash loan capabilities.</p>
                            <div class="feature">✅ Simple arbitrage between DEXs</div>
                            <div class="feature">✅ Flash loan arbitrage</div>
                            <div class="feature">✅ Triangular arbitrage</div>
                            <div class="feature">✅ Price monitoring</div>
                        </div>
                        <div class="contract-card">
                            <h3>Arbitrage.sol</h3>
                            <p>Simple arbitrage trading between Uniswap and Sushiswap</p>
                            <div class="feature">⚡ Fast execution</div>
                            <div class="feature">🔧 Configurable slippage</div>
                        </div>
                        <div class="contract-card">
                            <h3>FlashLoan.sol</h3>
                            <p>Basic flash loan implementation using Aave protocol</p>
                            <div class="feature">💰 No upfront capital</div>
                            <div class="feature">🔄 Instant execution</div>
                        </div>
                    </div>
                </div>
                
                <div class="section">
                    <h2>Development Commands</h2>
                    <div class="command">npm run compile</div>
                    <p>Compile all smart contracts</p>
                    <div class="command">npm run deploy</div>
                    <p>Deploy contracts to blockchain (requires configuration)</p>
                </div>
                
                <div class="section api-section">
                    <h2>API Endpoints</h2>
                    <p><a href="/api/contracts" class="btn">📋 View Compiled Contracts</a></p>
                    <p><a href="/api/opportunities" class="btn">🎯 Arbitrage Opportunities</a></p>
                    <p><strong>Price Monitoring:</strong> /api/prices/:tokenA/:tokenB/:amount</p>
                </div>
                
                <div class="section">
                    <h2>Features</h2>
                    <div class="contract-grid">
                        <div class="feature">
                            <h4>🔄 Multi-Strategy Arbitrage</h4>
                            <p>Execute simple, flash loan, and triangular arbitrage strategies</p>
                        </div>
                        <div class="feature">
                            <h4>📊 Real-time Monitoring</h4>
                            <p>Monitor price differences across multiple DEXs</p>
                        </div>
                        <div class="feature">
                            <h4>⚡ Flash Loan Integration</h4>
                            <p>Leverage Aave flash loans for capital-free arbitrage</p>
                        </div>
                        <div class="feature">
                            <h4>🛡️ Risk Management</h4>
                            <p>Built-in slippage protection and emergency functions</p>
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>
    `);
});

// Initialize trading engine
tradingEngine.initialize().then(() => {
    console.log('Trading engine ready');
}).catch(console.error);

server.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Ultimate Arbitrage Platform running on http://0.0.0.0:${PORT}`);
    console.log('📊 Real-time trading dashboard available');
    console.log('🔧 WebSocket connections enabled for live updates');
    console.log('⚡ Flash loan arbitrage system active');
    console.log('\n💡 Quick Start:');
    console.log('1. Compile contracts: npm run compile');
    console.log('2. Deploy contract: npm run deploy');
    console.log('3. Set CONTRACT_ADDRESS in environment');
    console.log('4. Connect wallet and start trading!');
});
